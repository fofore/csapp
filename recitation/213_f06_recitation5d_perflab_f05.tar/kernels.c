/*
 * Kernels to be optimized for the CS:APP Performance Lab
 */

// Name (Andrew ID)
//
// (5 pts)
// Replace these lines with a comment block describing the different
// techniques you used to optimize the matvec function.  Discuss why
// these techniques decreased the CPE. Identify which combination of
// techniques produced the most improvement.
//


#include <stdio.h>
#include <stdlib.h>
#include "defs.h"

/* Data structures defined in driver.c */
extern val_t A[][N];
extern val_t x[];
extern val_t y[];

/*******************************************************
 * Part I: Define functions
 *
 * Your different versions of the matvec kernel go here.
 *******************************************************/

/* 
 * matvec_baseline - The simple baseline version of matvec
 */
char matvec_baseline_descr[] = "matvec_baseline: Baseline implementation";
void matvec_baseline(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
	for (j = 0; j < N; j++) {
	    y[i] = y[i] + A[i][j] * x[j];
	}
    }	    
}

/* 
 * matvec_col - A version of matvec that works on cols instead rows.
 */ 
char matvec_col_descr[] = "matvec_col: column-wise";
void matvec_col(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
    }
    for (j = 0; j < N; j++) {
	for (i = 0; i < N; i++) {
	    y[i] = y[i] + A[i][j] * x[j];
	}
    }	    
}

char matvec_accumulator_descr[] = "baseline + accumulator variable";
void matvec_accumulator (val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;
    val_t temp;

    for (i = 0; i < N; i++) {
	temp = 0.0;
        for (j = 0; j < N; j++) {
            temp += A[i][j] * x[j];
        }
	y[i] = temp;
    }
}

char matvec_parallelism_descr[] = "baseline with parallelism";
void matvec_parallelism (val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;
    int length = N - 2;
    val_t temp;

    for (i = 0; i < N; i++) {
	temp = 0.0;

        for (j = 0; j < length; j += 3) {
            temp += A[i][j] * x[j] + A[i][j+1] * x[j+1] + A[i][j+2] * x[j+2];
        }
	for ( ; j < N; j++) {
	    temp += A[i][j] * x[j];
	}
	y[i] = temp;
    }
}

char matvec_final_descr[] = "final solution with unrolling and blocking";
void matvec_final (val_t A[N][N], val_t *x, val_t *y) {

    int i, j;
    float temp,
        t0, t1, t2, t3, t4, t5, t6, t7;

    int size = N - 8;

    for (i = 0; i < size; i += 8) {

        t0 = t1 = t2 = t3 = t4 = t5 = t6 = t7 = 0.0;

        for (j = 0; j < N; j++) {
            /* cache x[j] */
            temp = x[j];

            /* look at 8 rows at a time, taking
               advantage of the 64 byte block size */
            t0 += A[i][j]     * temp;
            t1 += A[i + 1][j] * temp;
            t2 += A[i + 2][j] * temp;
            t3 += A[i + 3][j] * temp;
            t4 += A[i + 4][j] * temp;
            t5 += A[i + 5][j] * temp;
            t6 += A[i + 6][j] * temp;
            t7 += A[i + 7][j] * temp;
        }
        /* update y */
        y[i]     = t0;
        y[i + 1] = t1;
        y[i + 2] = t2;
        y[i + 3] = t3;
        y[i + 4] = t4;
        y[i + 5] = t5;
        y[i + 6] = t6;
        y[i + 7] = t7;
    }

    /* clean up the rest */
    for ( ; i < N; i++) {
        temp = 0.0;
        for (j = 0; j < N; j++) {
            temp += A[i][j] * x[j];
        }
        y[i] = temp;
    }
}

/******************************************************************
 * Part II: Register the functions defined in Part I
 *
 * Here is where you register all of your different versions of the
 * matvec kernel with the driver by calling add_function() for each
 * test function. When you run the driver program, it will test and
 * report the performance of each registered test function.
 ******************************************************************/

void register_functions() 
{
    add_function(&matvec_baseline, matvec_baseline_descr);   
    add_function(&matvec_col, matvec_col_descr);   

    /* register additional versions here */
    add_function(&matvec_accumulator, matvec_accumulator_descr);
    add_function(&matvec_parallelism, matvec_parallelism_descr);
    add_function(&matvec_final, matvec_final_descr);
}




