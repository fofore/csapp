/*
 * Kernels to be optimized for the CS:APP Performance Lab
 */

// Name (Andrew ID)
//
// (5 pts)
// Replace these lines with a comment block describing the different
// techniques you used to optimize the matvec function.  Discuss why
// these techniques decreased the CPE. Identify which combination of
// techniques produced the most improvement.
//


#include <stdio.h>
#include <stdlib.h>
#include "defs.h"

/* Data structures defined in driver.c */
extern val_t A[][N];
extern val_t x[];
extern val_t y[];

/*******************************************************
 * Part I: Define functions
 *
 * Your different versions of the matvec kernel go here.
 *******************************************************/

/* 
 * matvec_baseline - The simple baseline version of matvec
 */
char matvec_baseline_descr[] = "matvec_baseline: Baseline implementation";
void matvec_baseline(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
	for (j = 0; j < N; j++) {
	    y[i] = y[i] + A[i][j] * x[j];
	}
    }	    
}

char matvec_baseline_temp_descr[] = "matvec_baseline: Baseline implementation, using temp variable";
void matvec_baseline_temp(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;
    val_t temp;

    for (i = 0; i < N; i++) {
        temp = 0.0;
        for (j = 0; j < N; j++) {
            temp +=  A[i][j] * x[j];
        }
        y[i] = temp;
    }	    
}

char matvec_baseline_unrolling_x_2_descr[] = "matvec_baseline: Baseline implementation, unrolling x by 2"; 
void matvec_baseline_unrolling_x_2(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;
    val_t temp, temp1;

    for (i = 0; i + 1 < N; i = i + 2) {
        temp = 0.0;
        temp1 = 0.0;
        for (j = 0; j < N; j++) {
            temp +=  A[i][j] * x[j];
            temp1 += A[i+1][j] * x[j];
        }
        y[i] = temp;
        y[i+1] = temp1;
    }
    for (; i<N; i++) {
        temp = 0.0;
        for (j = 0; j < N; j++) 
            temp += A[i][j] * x[j];
        y[i] = temp;
    }
}

char matvec_baseline_unrolling_y_2_descr[] = "matvec_baseline: Baseline implementation, using unrolling_y_2 ";
void matvec_baseline_unrolling_y_2(val_t A[N][N], val_t *x, val_t *y)
{

    /* unrolling_y_2 by 2 */
    int i, j;
    val_t temp;

    for (i = 0; i < N; i++) {
        temp = 0.0;
        for (j = 0; j+1 < N; j = j + 2) 
            temp +=  (A[i][j] * x[j] + A[i][j+1] * x[j+1]);
        /*
         * temp = temp + A[i][j] * x[j];
         * temp = temp + A[i][j+1] * x[j+1];
         */
        for (; j < N; j++)
            temp += A[i][j] * x[j];
        y[i] = temp;
    }	    
}
char matvec_baseline_unrolling_y_4_descr[] = "matvec_baseline: Baseline implementation, using unrolling by 4 ";
void matvec_baseline_unrolling_y_4(val_t A[N][N], val_t *x, val_t *y)
{

    /* unrolling by 4 */
    int i, j;
    val_t temp;

    for (i = 0; i < N; i++) {
        temp = 0.0;
        for (j = 0; j+3 < N; j = j + 4) 
            temp +=  (A[i][j] * x[j] + A[i][j+1] * x[j+1] + A[i][j+2] * x[j+2] + A[i][j+3]*x[j+3]);
        for (; j < N; j++)
            temp += A[i][j] * x[j];
        y[i] = temp;
    }	    
}
char matvec_baseline_unrolling_y_6_descr[] = "matvec_baseline: Baseline implementation, using unrolling by 6";
void matvec_baseline_unrolling_y_6(val_t A[N][N], val_t *x, val_t *y)
{

    /* unrolling_y_2 by 2 */
    int i, j;
    val_t temp;

    for (i = 0; i < N; i++) {
        temp = 0.0;
        for (j = 0; j+5 < N; j = j + 6) 
            temp +=  (A[i][j] * x[j] + A[i][j+1] * x[j+1] + A[i][j+2] * x[j+2] + 
                    A[i][j+3]*x[j+3] + A[i][j+4] * x[j+4] + A[i][j+5] * x[j+5]);
        for (; j < N; j++)
            temp += A[i][j] * x[j];
        y[i] = temp;
    }	    
}
/* 
 * matvec_col - A version of matvec that works on cols instead rows.
 */ 
char matvec_col_descr[] = "matvec_col: column-wise";
void matvec_col(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
    }
    for (j = 0; j < N; j++) {
	for (i = 0; i < N; i++) {
	    y[i] = y[i] + A[i][j] * x[j];
	}
    }	    
}

/******************************************************************
 * Part II: Register the functions defined in Part I
 *
 * Here is where you register all of your different versions of the
 * matvec kernel with the driver by calling add_function() for each
 * test function. When you run the driver program, it will test and
 * report the performance of each registered test function.
 ******************************************************************/

void register_functions() 
{
    add_function(&matvec_baseline, matvec_baseline_descr);   
    add_function(&matvec_col, matvec_col_descr);   
    add_function(&matvec_baseline_temp, matvec_baseline_temp_descr);   
    add_function(&matvec_baseline_unrolling_y_2, matvec_baseline_unrolling_y_2_descr);   
    add_function(&matvec_baseline_unrolling_y_4, matvec_baseline_unrolling_y_4_descr);   
    add_function(&matvec_baseline_unrolling_y_6, matvec_baseline_unrolling_y_6_descr);   
    add_function(&matvec_baseline_unrolling_x_2, matvec_baseline_unrolling_x_2_descr);   
    /* register additional versions here */
}




