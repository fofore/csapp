/*******************************************************************
 * 
 * driver.c - Autolab driver program for CS:APP Performance Lab
 * 
 ********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

#include "driverlib.h"
#include "ftimer.h"
#include "defs.h"

/* 
 * Global matrix and vectors. 
 */
val_t A[N][N];   /* input matrix */
val_t x[N+N];    /* input vector (last N elements are guards) */
val_t y[N];      /* output vector Ax = y */
val_t yref[N];   /* reference solution vector */

/* Array of benchmark codes */
typedef struct {
    lab_test_func tfunc;  /* The test function */
    double cpe;           /* CPE for this benchmark */
    char *description;    /* ASCII description of the test function */
} bench_t;
bench_t benchmarks[MAXBENCH];
int benchmark_count = 0;

/* Autolab buffers */
char result[MAXBUF];
char status[MAXBUF];

/* Other globals */
int arg_summary = 0;         /* set by -s */
int arg_autograded = 0;      /* set only on the Autolab server */
double bestcpe = 99999.0;    /* Keeps track of function with best CPE */
char *bestcpe_desc = NULL;

/* Function prototypes */
void usage(char *progname);
void init_matrix(val_t A[][N]);
void init_input_vector(val_t *vec);
void clear_output_vector(val_t *vec);
void test_matvec(int bench_index, double Mhz, int iters);
void ref_matvec(val_t A[][N], val_t *x, val_t *y);

/*
 * Main routine
 */
int main(int argc, char *argv[])
{
    char c;
    int i;
    double mhz = get_mhz();


    /* Initialization */
    init_timeout();
    printf("N=%d, system clock rate=%.0lf MHz\n", N, mhz);
    
    /* Register all the defined functions */
    register_functions();

    /* parse command line args */
    while ((c = getopt(argc, argv, "hsA")) != -1)
	switch (c) {

	case 'A': /* hidden Autolab driver argument */
	    arg_autograded = 1;
	    break;

	case 's': /* print only a summary */
	    arg_summary = 1;
	    break;

	case 'h': /* print help message */
	    usage(argv[0]);

	default: /* unrecognized argument */
	    usage(argv[0]);
	}

    /* Initialize and touch the input data */
    init_matrix(A);
    init_input_vector(x);

    /* Compute the reference solution */
    clear_output_vector(yref);
    ref_matvec(A, x, yref);

    /* Test each benchmark */
    for (i = 0; i < benchmark_count; i++) {
	test_matvec(i, mhz, ITERS);
    }

    /* Print best score */
    printf("\nBest score: %.2f ACPE [%s]\n", bestcpe, bestcpe_desc);

    /* Post result to Autolab */
    sprintf(result, "%.2f", bestcpe);
    driver_post(NULL, result, arg_autograded, status);

    exit(0);
}

/* 
 * add_function - Adds a benchmark to a list of benchmarks
 */
void add_function(lab_test_func f, char *description) 
{
    benchmarks[benchmark_count].tfunc = f;
    benchmarks[benchmark_count].description = description;
    benchmark_count++;
}

/*
 * test_matvec - Test a bencmark solution
 */
void test_matvec(int bench_index, double mhz, int iters) 
{
    int i;
    double start, secs, cycles, cpe;
    char *description = benchmarks[bench_index].description;
    lab_test_func func = benchmarks[bench_index].tfunc;    

    /* Warm up all the hardware and OS caches */
    func(A, x, y);
    clear_output_vector(y);

    /* Time the function */
    init_etime();
    start = get_etime();
    for (i=0; i < iters; i++) {
	func(A, x, y);
    }
    secs = ((get_etime() - start)/iters);
    cycles = secs * (mhz * 1.0e6);
    cpe = cycles/(N*N);

    /* Check the computed result for correctness */
    for (i=0; i < N; i++) {
	if (y[i] != yref[i]) {
	    printf("\nError in function: %s\ny[%d]=%f but should be %f\n", 
		   description, i, y[i], yref[i]);
	    exit(1);
	}
    }
	
    /* Print the performance results for this benchmark */
    if (!arg_summary) {
	printf("%s: %.2f\n", description, cpe);
	fflush(stdout);
    }

    /* Keep track of the best cpe so far */
    if (cpe < bestcpe) {
	bestcpe = cpe;
	bestcpe_desc = description;
    }
}

/*
 * ref_matvec - The reference matrix vector product code
 */
void ref_matvec(val_t A[][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
	for (j = 0; j < N; j++) {
	    y[i] += A[i][j] * x[j];
	}
    }	    
}

/*
 * init_matrix - Initialize the input matrix
 */
void init_matrix(val_t A[][N])
{
    int i, j;

    for (i=0; i < N; i++) {
	for (j=0; j < N; j++) {
	    A[i][j] = i+j; 
	}
    }
}

/*
 * init_input_vector - Initialize the input vector
 */
void init_input_vector(val_t *vec)
{
    int i;

    for (i=0; i < N; i++) {
	vec[i] = 1.0;
    }

    /* Guard words to detect when students read past the end of x */
    for (i=N; i < 2*N; i++) {
	vec[i] = -9999.0;
    }
}

/*
 * clear_output_vector - Initialize the output vector
 */
void clear_output_vector(val_t *vec)
{
    int i;

    for (i=0; i < N; i++) {
	vec[i] = 0;
    }
}

/*
 * usage - print a usage message 
 */
void usage(char *progname) {
    printf("usage: %s [-hg]\n", progname);
    printf("  -h    Print this message\n");
    printf("  -s    Print summary of best score only\n"); 
    exit(0);
}













