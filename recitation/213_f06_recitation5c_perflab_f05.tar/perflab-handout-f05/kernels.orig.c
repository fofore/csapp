/*
 * Kernels to be optimized for the CS:APP Performance Lab
 */

// Name (Andrew ID)
//
// (5 pts)
// Replace these lines with a comment block describing the different
// techniques you used to optimize the matvec function.  Discuss why
// these techniques decreased the CPE. Identify which combination of
// techniques produced the most improvement.
//


#include <stdio.h>
#include <stdlib.h>
#include "defs.h"

/* Data structures defined in driver.c */
extern val_t A[][N];
extern val_t x[];
extern val_t y[];

/*******************************************************
 * Part I: Define functions
 *
 * Your different versions of the matvec kernel go here.
 *******************************************************/

/* 
 * matvec_baseline - The simple baseline version of matvec
 */
char matvec_baseline_descr[] = "matvec_baseline: Baseline implementation";
void matvec_baseline(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
	for (j = 0; j < N; j++) {
	    y[i] = y[i] + A[i][j] * x[j];
	}
    }	    
}

/* 
 * matvec_col - A version of matvec that works on cols instead rows.
 */ 
char matvec_col_descr[] = "matvec_col: column-wise";
void matvec_col(val_t A[N][N], val_t *x, val_t *y)
{
    int i, j;

    for (i = 0; i < N; i++) {
	y[i] = 0.0;
    }
    for (j = 0; j < N; j++) {
	for (i = 0; i < N; i++) {
	    y[i] = y[i] + A[i][j] * x[j];
	}
    }	    
}

/******************************************************************
 * Part II: Register the functions defined in Part I
 *
 * Here is where you register all of your different versions of the
 * matvec kernel with the driver by calling add_function() for each
 * test function. When you run the driver program, it will test and
 * report the performance of each registered test function.
 ******************************************************************/

void register_functions() 
{
    add_function(&matvec_baseline, matvec_baseline_descr);   
    add_function(&matvec_col, matvec_col_descr);   

    /* register additional versions here */
}




