/*
 * defs.h - Various definitions for the performance lab
 */

#define N 257          /* matrix A is NxN */
#define MAXBENCH 100   /* Max number of benchmark solutions */
#define ITERS 1000     /* Number of iterations of each benchmark */
#define MAXBUF 128     /* Maximum size of autoresult string */       

/* The data type for the A, x, and y */
typedef float val_t;

typedef void (*lab_test_func) (val_t A[N][N], val_t *x, val_t *y);

/* function prototypes */
void add_function(lab_test_func f, char *description); 
void register_functions(void);
void matvec(val_t A[N][N], val_t *x, val_t *y);


